/*********************************************
 * OPL 12.9.0.0 Model
 * Author: daby34
 * Creation Date: 6 ���. 2026 �. at 20:46:00
 *********************************************/
int n = ...;
int m = ...;
int m1 = ...;
int n1 = ...;
int m2 = m - m1;
int n2 = n - n1;
range j1 = 1..n1;
range j2 = 1..n2;
range i1 = 1..m1;
range i2 = 1..m2;
float b1[i1] = ...;
float b2[i2] = ...;
float z1[j1] = ...;
float z2[j2] = ...;
float A3[i2][j2] = ...;
float A1[i1][j1] = ...;
float A2[i2][j1] = ...;
 float MaxValue = 1000*max(r in i2) b2[r];
dvar float x[j1] in 0..MaxValue;
dvar boolean w[j2];
minimize
 sum(jj in j1) z1[jj] * x[jj] +
 sum(jjj in j2) z2[jjj] * w[jjj] ;

subject to {
 forall( r1 in i1 )
 ct1:
 sum( jj in j1)
 A1[r1][jj] * x[jj] <= b1[r1];

 forall( r in i2 )
 ct2:
 sum( jj in j1 )
 A2[r][jj] * x[jj] +
 sum( jjj in j2)
 A3[r][jjj] * w[jjj] <= b2[r];
}